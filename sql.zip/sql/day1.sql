use digital;

update Employee set salary=50000 where id=2;
update Employee set name='hari' where id=2;
select * from employee;

alter table Employee add column dept varchar(30);
alter table Employee add column age int;

update employee set dept='hr',age=24 where id=1;

update employee set dept='developer',age=24 where id=2;


insert into Employee values(3,'ravi',40000,'tester',27);
insert into Employee values(4,'sam',42000,'cloud',25);
insert into Employee values(5,'rakesh',50000,'hr',23);
insert into Employee values(6,'ram',52000,'developer',26);


select name,salary as sal,salary+5000 as bonus from employee

select * from Employee where id>3 or salary > 50000;
select * from Employee where binary dept='Hr';
select * from Employee where dept<>'hr';

select * from Employee where name='sam';

select * from employee where salary between 50000 and 55000;
select name from employee where age between 25 and 30;

select * from employee where dept='hr' or dept='developer';

select * from Employee where id in (1,2,10,4)

select * from employee where salary in (select salary from employee where name='sam');

select * from employee where salary > any (select salary from employee where name='sam');
select * from employee where salary > all (select salary from employee where name='sam');

select * from employee where name like 'r%';
select * from employee where name like '%m';
select * from employee where name like '%a_';
select * from employee where name like '%a%';

select * from employee order by salary asc;
select * from employee order by salary desc;

select * from employee order by age;
select * from employee limit 2;
select * from employee limit 2,1;

select * from employee order by salary desc limit 1;
select * from employee order by salary asc limit 1,1;

select min(salary) from employee;
select max(salary) from employee;
select count(salary) from employee;

select name,upper(name) from employee;
select name,lower(name) from employee;
select name,length(name) from employee;
select name,concat(name,'vm') from employee;

select dept,count(name),max(salary),min(salary)  from employee group by dept;

select dept,count(name) from employee group by dept;
insert into Employee values(7,'ashish',41000,'tester',21);
insert into Employee values(8,'suresh',43000,'tester',24);
insert into Employee values(9,'teja',53000,'hr',25);
insert into Employee values(10,'krishna',51000,'tester',27);
select*from employee;

select dept,count(name) from employee group by dept order by count(dept) desc;

select dept,count(name) from employee
group by dept
having count(name)>2
order by count(name) desc

select dept,sum(salary) from employee 
group by dept having sum(salary)>75000
order by sum(salary) desc;


select dept,sum(salary) from employee 
group by dept having sum(salary)>75000
order by sum(salary) desc limit 1,1;

















